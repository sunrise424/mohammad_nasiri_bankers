/*import java.io.*;
import java.util.*;

public class Factory {
    public static void main(String[] args) {

            // String filename = "/Users/williammccarthy/IdeaProjects/BankersAlgorithmProject_ch7/src/infile.txt";
            String filename = "/Users/Reza/Desktop/Spring 2019/Banker/src/infile.txt";
           // String filename = "infile.txt";
            int nResources = args.length;
            int[] resources = new int[nResources];
            for (int i = 0; i < nResources; i++) {
                resources[i] = Integer.parseInt(args[i].trim());
            }

            Bank theBank = new BankImpl(resources);
            int[] maxDemand = new int[nResources];
            int[] allocated = new int[nResources];
            Thread[] workers = new Thread[Customer.COUNT];      // the customers

        //add to read txt file
            BufferedReader br;
            String[] inputArray;
            int threadNum = 0;

            try{
                br = new BufferedReader(new FileReader(filename));

                for (int i = 0; i<Customer.COUNT; i++){
                    inputArray = br.readLine().split(",");

                    for (int j = 0; j < nResources; j++ ){
                        allocated[j] = Integer.parseInt(inputArray[j]);
                        maxDemand[j] = Integer.parseInt(inputArray[j+3]);
                    }
                }



        Scanner scanner = new Scanner(System.in);  // Create a Scanner object to read txt

        try{


            // read in values and initialize the matrices
            // to do
            // ...
            workers[threadNum] = new Thread(new Customer(threadNum, maxDemand, theBank));
            theBank.addCustomer(threadNum, allocated, maxDemand);

            ++threadNum;        //theBank.getCustomer(threadNum);
        //    resourceNum = 0;



} catch (FileNotFoundException fnfe) { throw new Error("Unable to find file \"" + filename + "\"");
        } catch (IOException ioe) { throw new Error("Error processing \"" + filename + "\""); }

        System.out.println("FACTORY: created threads");     // start the customers

        for (int i = 0; i < Customer.COUNT; i++) { workers[i].start(); }
        System.out.println("FACTORY: started threads");

        }
        }*/
import java.io.*;
import java.util.*;

public class Factory {
    public static void main(String[] args) throws IOException  {
        // String filename = "/Users/williammccarthy/IdeaProjects/BankersAlgorithmProject_ch7/src/infile.txt";
        String filename = "/Users/Reza/Desktop/Spring 2019/Banker/src/infile.txt";
       // String filename = "infile.txt";
        int nResources = args.length;
        int[] resources = new int[nResources];
        for (int i = 0; i < nResources; i++) { resources[i] = Integer.parseInt(args[i].trim()); }

        Bank theBank = new BankImpl(resources);
        int[] maxDemand = new int[nResources];
        int[] allocated = new int[nResources];
        Thread[] workers = new Thread[Customer.COUNT];      // the customers
        char choice = 'a';
        String ch;
        boolean loop = true;
        boolean ran_this = true;


        Scanner scanner = new Scanner(System.in);  // Create a Scanner object

        try{
            // read in values and initialize the matrices
            // to do
            // ...

            BufferedReader br = null;
            br = new BufferedReader(new FileReader(filename));

            String temp = "";
            String[] arr;

            for(int threadNum = 0; threadNum < workers.length; threadNum++){
                temp = br.readLine();
                arr = temp.split(",");

                for(int i = 0; i < nResources; i++){
                    allocated[i] = Integer.parseInt(arr[i]);
                    maxDemand[i] = Integer.parseInt(arr[i + 3]);
                }
                System.out.println("adding customer " + threadNum + "...");
                workers[threadNum] = new Thread(new Customer(threadNum, maxDemand, theBank));
                theBank.addCustomer(threadNum, allocated, maxDemand);

                //++threadNum;        //theBank.getCustomer(threadNum);
                //resourceNum = 0;
            }

        } catch (FileNotFoundException fnfe) { throw new Error("Unable to find file \"" + filename + "\"");
        } catch (IOException ioe) { throw new Error("Error processing \"" + filename + "\""); }
      //  do{
            ran_this = false;
            System.out.println("Would you like to run Interactive mode(i), or Automatic Mode(a)?");
            choice =  scanner.nextLine().charAt(0);
            System.out.println("char is " + (char)choice);

            if(choice == 'a'){
                ran_this = false;
                System.out.println("FACTORY: created threads");     // start the customers

                System.out.println("FACTORY: started threads");
                for (int i = 0; i < Customer.COUNT; i++) { workers[i].start(); }
                //break;
            } else if(choice == 'i'){

                System.out.print("Enter * to get the system state, OR enter <RQ | RL> <customer number> <resource #0> <#1> <#2>");
                choice = scanner.nextLine().charAt(0);
                if(choice == '*'){
                    theBank.getState();
                }
            }
          //  System.out.println(theBank.Finished());
       // }while(!theBank.Finished());
    }
}
